import { CheckCircle2, Download } from "lucide-react";

const MIME_BY_EXT = {
  mp4: "video/mp4",
  webm: "video/webm",
  ogg: "video/ogg",
  mov: "video/quicktime", // supported by Safari only — convert to mp4 for Chrome/Firefox
};

function guessType(src) {
  const ext = src.split(".").pop().toLowerCase();
  return MIME_BY_EXT[ext] || "video/mp4";
}

export default function VideoFeature({ src, poster, kicker, title, text, points }) {
  return (
    <div className="rw-section" style={{ paddingTop: 0 }}>
      <div className="rw-section-head">
        {kicker && <div className="rw-kicker">{kicker}</div>}
        <h2>{title}</h2>
      </div>

      <div className="rw-video-frame">
        <video className="rw-video" controls preload="metadata" poster={poster}>
          <source src={src} type={guessType(src)} />
        </video>
      </div>
      <p className="rw-video-fallback">
        Video not playing? <a href={src} download><Download size={13} style={{ verticalAlign: -2 }} /> Download it directly</a>
      </p>

      <div className="rw-video-copy">
        <p>{text}</p>
        {points && (
          <ul className="rw-check-list rw-video-points">
            {points.map((p) => (
              <li key={p}><CheckCircle2 size={18} /> {p}</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
